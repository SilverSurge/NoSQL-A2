import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.io.DataInput;
import java.io.DataOutput;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.fs.Path;
// import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.StringUtils;

import opennlp.tools.stemmer.PorterStemmer;


class CompositeValue implements WritableComparable<CompositeValue> {

    private String doc;
    private int count;
    // Default constructor for (de)serialization
    public CompositeValue() {
        doc = new String();
        doc = "";
        count = 0;
    }

    public CompositeValue(String _doc, int _count) {
        doc = _doc;
        count = _count;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        WritableUtils.writeString(out, doc);
        out.writeInt(count);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        doc = WritableUtils.readString(in);
        count = in.readInt();
    }

    @Override
    public int compareTo(CompositeValue o) {
        int result = doc.compareTo(o.doc);
        if (result == 0) {
            Integer int1 = count;
            Integer int2 = o.get_count();
            result = int1.compareTo(int2);
        }
        return result;
    }

    // Getters and setters

    public String get_doc() {
        return doc;
    }

    public void set_doc(String _doc) {
        doc = _doc;
    }

    public int get_count() {
        return count;
    }

    public void set_count(int _count) {
        count = _count;
    }

    

    @Override
    public int hashCode() {
        // Implement your own hash code logic, perhaps using Objects.hash(word1, word2)
        return doc.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof CompositeValue) {
            CompositeValue other = (CompositeValue) o;
            return doc.equals(other.get_doc()) && count == other.get_count();
        }
        return false;
    }

    @Override
    public String toString() {
        // try to figure why we did this
        // #bigbrains #puzzles
        return Integer.toString(count);
    }
    
};

public class Q2A {

    // // helper class
    private static class WordCountDS {
        // attributes
        private String word;
        private int count;

        // constructor
        public WordCountDS(String _word, int _count) {
        this.word = _word;
        this.count = _count;
        }

        // some getters
        public String get_word() {
        return this.word;
        }

        public int get_count() {
        return this.count;
        }
    };

    public static class WordCountDSComparator implements Comparator<WordCountDS> {
        @Override
        public int compare(WordCountDS obj1, WordCountDS obj2) {
            // Compare based on the id field
            if(obj1.get_count() == obj2.get_count())
                return obj2.get_word().compareTo(obj1.get_word());
            return Integer.compare(obj1.get_count(), obj2.get_count());
        }
    }

    public static class Mapper_1 extends Mapper<Object, Text, Text, CompositeValue> {
        // attributes for emitting
        // private final static IntWritable one = new IntWritable(1);
        CompositeValue cval = new CompositeValue();
        Text word = new Text();

        // attributes related to the task
        private boolean case_sensitive = false;
        private Set<String> patterns_to_skip = new HashSet<String>();

        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            case_sensitive = conf.getBoolean("wordcount.case.sensitive", false);
            if (conf.getBoolean("wordcount.skip.patterns", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseSkipFile(patternsFileName);
                }
            }
        }

        private void parseSkipFile(String fileName) {
            // read the file and add the patterns to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    patterns_to_skip.add(pattern);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // get filename
            FileSplit fileSplit = (FileSplit) context.getInputSplit();
            String filename = fileSplit.getPath().getName();
            
            // change to lower case if not case sensitive
            String line = (case_sensitive) ? value.toString() : value.toString().toLowerCase();
            
            // remove the skipwords
            for (String pattern : patterns_to_skip) {
                line = line.replaceAll("\\b" + pattern + "\\b", "");
            }

            // split the line in words
            String[] tokens = line.split("[^\\w']+");
            
            // emit [{word, fname}, one]
            cval.set_doc(filename);
            cval.set_count(1);
            PorterStemmer stemmer = new PorterStemmer();
            for (String token : tokens) {
                // word.set(token);
                word.set(stemmer.stem(token));
                context.write(word, cval);
            }

        }
        

    }

    
    // public static class Reducer_1 extends Reducer<CompositeKey, IntWritable, CompositeKey, IntWritable> {

    //     private CompositeKey ckey = new CompositeKey();
    //     private final static IntWritable one = new IntWritable(1);

    //     @Override
    //     public void reduce(CompositeKey key, Iterable<IntWritable> values, Context context)
    //             throws IOException, InterruptedException {
            
    //         ckey.setWord1(key.getWord1());
    //         ckey.setWord2(key.getWord1());
    //         context.write(ckey, one);
    //     }

    // }


    public static class Reducer_1 extends Reducer<Text, CompositeValue, Text, CompositeValue> {


        private CompositeValue cval = new CompositeValue();
        private Text word = new Text();
        // heap for top 100 words
        private PriorityQueue<WordCountDS> top_100_words;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            // initialize the heap
            WordCountDSComparator comp = new WordCountDSComparator();
            top_100_words = new PriorityQueue<>(100, comp);
        }

		@Override
		public void reduce(Text key, Iterable<CompositeValue> values, Context context)
				throws IOException, InterruptedException {

            HashSet<String> docnames =  new HashSet<>();
			for (CompositeValue cv : values) {
				docnames.add(cv.get_doc());
			}

            int df = docnames.size();
            // Add the word and its count to the priority queue
            top_100_words.add(new WordCountDS(key.toString(), df));

            // Keep the queue size at most 100
            if (top_100_words.size() > 100) {
                top_100_words.poll(); // Remove the least frequent word
            }
		}

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            // Emit the top 50 most frequently occurring words
            List<WordCountDS> top_word_list = new ArrayList<>();
            while (!top_100_words.isEmpty()) {
                top_word_list.add(top_100_words.poll());
            }

            // Emit the top 50 words in descending order of their counts
            for (int i = top_word_list.size() - 1; i >= 0; i--) {
                WordCountDS wcds = top_word_list.get(i);
                // ckey.setWord1(wcds.get_word());
                // ckey.setWord2(wcds.get_word());
                // count.set(wcds.get_count());
                word.set(wcds.get_word());
                cval.set_doc(wcds.get_word());
                cval.set_count(wcds.get_count());
                context.write(word, cval);
            }
        }
	}

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "q2a");

        job.setMapperClass(Mapper_1.class);
        // job.setCombinerClass(Reducer_1.class); 
        // enable to use 'local aggregation'
        job.setReducerClass(Reducer_1.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(CompositeValue.class);

        for (int i = 0; i < args.length; ++i) {
			if ("-skippatterns".equals(args[i])) {
				job.getConfiguration().setBoolean("wordcount.skip.patterns", true);
				job.addCacheFile(new Path(args[++i]).toUri());
			} else if ("-casesensitive".equals(args[i])) {
				job.getConfiguration().setBoolean("wordcount.case.sensitive", true);
			}
		}

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setJarByClass(Q2A.class);
        job.waitForCompletion(true);
        // System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}


// /home/ricky/Desktop/sem6/NoSql/final_codes/q2a/q2a.jar
// hadoop jar q2a.jar /tar_testers /outputs/q2a -skippatterns /stopWords/stopwords.txt -casesensitive

