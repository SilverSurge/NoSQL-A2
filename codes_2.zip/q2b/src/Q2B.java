import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.io.DataInput;
import java.io.DataOutput;
import java.lang.Math;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.StringUtils;

import opennlp.tools.stemmer.PorterStemmer;


class CompositeValue implements WritableComparable<CompositeValue> {

    private int n;
    private ArrayList<Double> counts;
    // Default constructor for (de)serialization
    public CompositeValue() {
        n = 0;
        counts = new ArrayList<Double>();
    }

    public CompositeValue(int _n) {
        n = _n;
        counts = new ArrayList<Double>(n);
        for(int i=0; i<n; i++)
            counts.add(0.0);
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeInt(n);
        for (int i = 0; i < n; i++) {
            out.writeDouble(counts.get(i));
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        n = in.readInt();
        counts.clear(); // Clear existing counts
        for (int i = 0; i < n; i++) {
            counts.add(in.readDouble());
        }
    }

    // helper functions

    public void reset()
    {
        for(int i=0; i<n; i++)
            counts.set(i, 0.0);
    }
    public void increment(int _idx)
    {
        if(_idx < n && _idx >= 0)
        {
            counts.set(_idx, counts.get(_idx)+1);
        }
    }

    public int get_n()
    {
        return n;
    }

    public double get_idx(int idx)
    {
        if(idx < n && idx >= 0)
            return counts.get(idx);
        return 0;
    }

    public void set_idx(int idx, double value)
    {
        if(idx < n && idx >= 0)
            counts.set(idx, value);
    }

    void add(CompositeValue cval)
    {
        if(cval.get_n() != n)
            return;
        for(int i=0; i < n; i++)
        {
            counts.set(i, counts.get(i) + cval.get_idx(i));
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + n;
        result = prime * result + ((counts == null) ? 0 : counts.hashCode());
        return result;
    }


    @Override
    public String toString() {
        String res = "";
        for(int i=0; i<n; i++)
            res += counts.get(i).toString() + "\t";
        return res;
    }

    @Override
    public int compareTo(CompositeValue o) {
        // don't need to compare
        return 0;
    }
    
};

public class Q2B {


    public static class Mapper_1 extends Mapper<Object, Text, Text, CompositeValue> {
        // attributes for emitting
        CompositeValue cval = new CompositeValue();
        Text docname = new Text();
        // attributes related to the task
        private boolean case_sensitive = false;
        private ArrayList<String> word_100 = new ArrayList<String>();


        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            case_sensitive = conf.getBoolean("wordcount.case.sensitive", false);
            if (conf.getBoolean("wordcount.wordlist", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseWordFile(patternsFileName);
                }
            }
            
            Collections.sort(word_100);
            cval = new CompositeValue(word_100.size());
        }

        private int find_idx(String word) {
            int idx = 0;
            for (String w : word_100) {
                if(word.equals(w))
                    return idx;
                idx++;
            }
            return -1;
        }


        private void parseWordFile(String fileName) {
            // read the file and add the words to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    word_100.add(pattern.split("\t")[0]);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }


        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // get filename
            FileSplit fileSplit = (FileSplit) context.getInputSplit();
            String filename = fileSplit.getPath().getName();
            
            // change to lower case if not case sensitive
            String line = (case_sensitive) ? value.toString() : value.toString().toLowerCase();

            // split the line in words
            String[] tokens = line.split("[^\\w']+");
            
            // emit [{doc}, {wordcounts}]
            docname.set(filename);

            PorterStemmer stemmer = new PorterStemmer();
            for (String token : tokens) {
                // word.set(token);
                String stemmed_word = stemmer.stem(token);
                if (word_100.contains(stemmed_word) )
                {
                    cval.reset();
                    cval.increment(find_idx(stemmed_word));
                    context.write(docname, cval);
                }
            }

        } 

    }



    public static class Reducer_1 extends Reducer<Text, CompositeValue, Text, CompositeValue> {

        private HashMap<String, Double> df_map = new HashMap<String, Double>();
        private ArrayList<String> word_100 = new ArrayList<String>();
        


        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            if (conf.getBoolean("wordcount.wordlist", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseWordFile(patternsFileName);
                }
            }
            Collections.sort(word_100);
        }

        private void parseWordFile(String fileName) {
            // read the file and add the words to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    String[] splits = pattern.split("\t"); 
                    df_map.put(splits[0], Double.parseDouble(splits[1]));
                    word_100.add(splits[0]);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }








		@Override
		public void reduce(Text key, Iterable<CompositeValue> values, Context context)
				throws IOException, InterruptedException {

			// double tf = 0;
			// for (DoubleWritable val : values) {
			// 	tf += val.get();
			// }
            // double df = df_map.get(key.getWord2());
            
            // score.set(tf * Math.log(1 + (1000.0/df)));
            // context.write(key, score);

            // adding all the values
            Iterator<CompositeValue> iterator = values.iterator();
            CompositeValue first = iterator.next();
            CompositeValue result = new CompositeValue(first.get_n());
            result.reset();
            result.add(first);
            
            for(CompositeValue value: values)
            {
                result.add(value);
                // context.write(key, value);
            }

            // result [TF array]
            for(int i=0; i<result.get_n(); i++)
            {
                double tf = result.get_idx(i);
                double df = df_map.get(word_100.get(i));
                double score = tf * Math.log(1 + (1000.0/df));

                result.set_idx(i, score);
            }
            context.write(key, result);
		}
	}

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "q2b");

        job.setMapperClass(Mapper_1.class);
        job.setReducerClass(Reducer_1.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(CompositeValue.class);

        for (int i = 0; i < args.length; ++i) {
			if ("-wordlist".equals(args[i])) {
				job.getConfiguration().setBoolean("wordcount.wordlist", true);
				job.addCacheFile(new Path(args[++i]).toUri());
			} else if ("-casesensitive".equals(args[i])) {
				job.getConfiguration().setBoolean("wordcount.case.sensitive", true);
			}
		}

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setJarByClass(Q2B.class);
        job.waitForCompletion(true);
        // System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

// /home/ricky/Desktop/sem6/NoSql/final_codes/q2b/q2b.jar
// hadoop jar q2b.jar /tar_testers /outputs/q2b -wordlist /outputs/q2a/part-r-00000 -casesensitive

