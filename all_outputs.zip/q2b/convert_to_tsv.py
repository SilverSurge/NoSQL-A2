def extract_words(file_path):
    word_list = []
    with open(file_path, 'r') as file:
        for line in file:
            # Split the line into words
            words = line.strip().split('\t')

            # Extract the word and add it to the list if not already present
            word = words[0]
            if word not in word_list:
                word_list.append(word)
    return word_list


def transform_file(input_file, output_file):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            # Split the line into filename and word counts
            parts = line.strip().split('\t')
            filename = parts[0]
            word_counts = parts[1:]

            # Iterate through word counts and write to output file
            for i, count in enumerate(word_counts):
                outfile.write(f"{filename}\t{words[i]}\t{count}\n")




#here file_path is the path to the output file of q2_parta
file_path = '/home/ricky/Desktop/sem6/NoSql/final_codes/question_outputs/q2a/part-r-00000'
words = extract_words(file_path)
words.sort()


# This is the file path to the output of the q2_partb
input_file = 'part-r-00000'

# final output file
output_file = 'output_file.txt'

transform_file(input_file, output_file)

