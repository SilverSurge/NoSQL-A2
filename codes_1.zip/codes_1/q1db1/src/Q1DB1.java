import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.io.DataInput;
import java.io.DataOutput;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.StringUtils;

class CompositeKey implements WritableComparable<CompositeKey> {

    private String word1;
    private String word2;

    // Default constructor for (de)serialization
    public CompositeKey() {
    }

    public CompositeKey(String word1, String word2) {
        this.word1 = word1;
        this.word2 = word2;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        WritableUtils.writeString(out, word1);
        WritableUtils.writeString(out, word2);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        word1 = WritableUtils.readString(in);
        word2 = WritableUtils.readString(in);
    }

    @Override
    public int compareTo(CompositeKey o) {
        int result = word1.compareTo(o.word1);
        if (result == 0) {
            result = word2.compareTo(o.word2);
        }
        return result;
    }

    // Getters and setters

    public String getWord1() {
        return word1;
    }

    public void setWord1(String word1) {
        this.word1 = word1;
    }

    public String getWord2() {
        return word2;
    }

    public void setWord2(String word2) {
        this.word2 = word2;
    }

    // hashCode() and equals() are important for grouping and partitioning

    @Override
    public int hashCode() {
        // Implement your own hash code logic, perhaps using Objects.hash(word1, word2)
        return (word1 + word2).hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof CompositeKey) {
            CompositeKey other = (CompositeKey) o;
            return word1.equals(other.word1) && word2.equals(other.word2);
        }
        return false;
    }

    @Override
    public String toString() {
        return "[" + word1 + ", " + word2 + "]";
    }
    
};

public class Q1DB1 {

    public static class Mapper_1 extends Mapper<Object, Text, CompositeKey, IntWritable> {
        // class level
        HashMap<CompositeKey, Integer> class_lvl_map = new HashMap<>();

        // attributes for emitting
        // private final static IntWritable one = new IntWritable(1);
        CompositeKey ckey = new CompositeKey();
        IntWritable num = new IntWritable();

        // attributes related to the task
        private boolean case_sensitive = false;
        private Set<String> word_50 = new HashSet<String>();
        private int distance = 1;

        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            case_sensitive = conf.getBoolean("wordcount.case.sensitive", false);
            if (conf.getBoolean("wordcount.top50", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseWordFile(patternsFileName);
                }
            }
            this.distance = conf.getInt("wordcount.distance", 1);
        }

        private void parseWordFile(String fileName) {
            // read the file and add the words to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    word_50.add(pattern.split("\t")[0]);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            // change to lower case if not case sensitive
            String line = (case_sensitive) ? value.toString() : value.toString().toLowerCase();

            // split the line in words
            String[] tokens = line.split("[^\\w']+");
            int n = tokens.length;
            int i = 0, j = 0;
            

            // using two pointers approach
            while (j < n) {
                while (j - i < this.distance && j < n)
                    j++;

                if (j>=n) {
                    break;
                }

                if (j - i == this.distance) {
                    if (this.word_50.contains(tokens[i]) && this.word_50.contains(tokens[j])) {
                        String w1 = tokens[i];
                        String w2 = tokens[j];
                        if (w1.compareTo(w2) < 0) {
                            // emit [{w1, w2}, 1]
                            ckey.setWord1(w1);
                            ckey.setWord2(w2);
                            // context.write(ckey, one);
                            if(!class_lvl_map.containsKey(ckey))
                            {
                                class_lvl_map.put(ckey, 1);
                            }
                            else 
                            {
                                int newcnt = class_lvl_map.get(ckey)+1;
                                class_lvl_map.put(ckey, newcnt);
                            }

                        } else {
                            // emit [{w2, w1}, 1]
                            ckey.setWord1(w2);
                            ckey.setWord2(w1);
                            // context.write(ckey, one);
                            if(!class_lvl_map.containsKey(ckey))
                            {
                                class_lvl_map.put(ckey, 1);
                            }
                            else 
                            {
                                int newcnt = class_lvl_map.get(ckey)+1;
                                class_lvl_map.put(ckey, newcnt);
                            }
                        }
                    }
                }
                i++;
            }

        }

        @Override
        protected void cleanup(Mapper<Object, Text, CompositeKey, IntWritable>.Context context)
                throws IOException, InterruptedException {
            
            for (Map.Entry<CompositeKey,Integer> entry : class_lvl_map.entrySet()) 
            {
                num.set(entry.getValue());
                context.write(entry.getKey(), num);
            } 
        }

    }

    public static class Reducer_1 extends Reducer<CompositeKey, IntWritable, CompositeKey, IntWritable> {

        @Override
        public void reduce(CompositeKey key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            int sum = 0;
            for (IntWritable val : values) {
                sum += val.get();
            }

            context.write(key, new IntWritable(sum));
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "a2b");

        job.setMapperClass(Mapper_1.class);
        job.setReducerClass(Reducer_1.class);

        job.setOutputKeyClass(CompositeKey.class);
        job.setOutputValueClass(IntWritable.class);

        for (int i = 0; i < args.length; ++i) {
            if ("-wordlist".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.top50", true);
                job.addCacheFile(new Path(args[++i]).toUri());
            } else if ("-casesensitive".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.case.sensitive", true);
            } else if ("-distance".equals(args[i])) {
                job.getConfiguration().setInt("wordcount.distance", Integer.parseInt(args[++i]));
            }
        }

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setJarByClass(Q1DB1.class);
        job.waitForCompletion(true);
    }
}

// cp /home/ricky/Desktop/sem6/NoSql/final_codes/q1db1/q1db1.jar ./
// hadoop jar q1db1.jar /tar_testers /outputs/q1db1 -wordlist /outputs/q1a/part-r-00000 -casesensitive -distance 2