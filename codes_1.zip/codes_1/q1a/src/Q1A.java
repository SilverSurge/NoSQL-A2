import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.StringUtils;

public class Q1A {

    // helper class
    private static class WordCountDS {
        // attributes
        private String word;
        private int count;

        // constructor
        public WordCountDS(String _word, int _count) {
            this.word = _word;
            this.count = _count;
        }

        // some getters
        public String get_word() {
            return this.word;
        }

        public int get_count() {
            return this.count;
        }
    };

    public static class WordCountDSComparator implements Comparator<WordCountDS> {
        @Override
        public int compare(WordCountDS obj1, WordCountDS obj2) {
            // Compare based on the id field
            if(obj1.get_count() == obj2.get_count())
                return obj2.get_word().compareTo(obj1.get_word());
            return Integer.compare(obj1.get_count(), obj2.get_count());
        }
    }

    public static class Mapper_1 extends Mapper<Object, Text, Text, IntWritable> {
        // attributes for emitting
        private final static IntWritable one = new IntWritable(1);
        private Text word = new Text();

        // attributes related to the task
        private boolean case_sensitive = false;
        private Set<String> patterns_to_skip = new HashSet<String>();

        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            case_sensitive = conf.getBoolean("wordcount.case.sensitive", false);
            if (conf.getBoolean("wordcount.skip.patterns", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseSkipFile(patternsFileName);
                }
            }
        }

        private void parseSkipFile(String fileName) {
            // read the file and add the patterns to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    patterns_to_skip.add(pattern);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            // change to lower case if not case sensitive
            String line = (case_sensitive) ? value.toString() : value.toString().toLowerCase();

            // remove the skipwords
            for (String pattern : patterns_to_skip) {
                line = line.replaceAll("\\b" + pattern + "\\b", "");
            }

            // split the line in words
            String[] tokens = line.split("[^\\w']+");

            // emit [word, one]
            for (String token : tokens) {
                word.set(token);
                context.write(word, one);
            }
        }

    }

    public static class Reducer_1 extends Reducer<Text, IntWritable, Text, IntWritable> {

        // heap for top 50 words
        private PriorityQueue<WordCountDS> top_50_words;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            // initialize the heap
            WordCountDSComparator comp = new WordCountDSComparator();
            top_50_words = new PriorityQueue<>(50, comp);
        }

        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            int sum = 0;
            for (IntWritable val : values) {
                sum += val.get();
            }

            // Add the word and its count to the priority queue
            top_50_words.add(new WordCountDS(key.toString(), sum));

            // Keep the queue size at most 50
            if (top_50_words.size() > 50) {
                top_50_words.poll(); // Remove the least frequent word
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            // Emit the top 50 most frequently occurring words
            List<WordCountDS> top_word_list = new ArrayList<>();
            while (!top_50_words.isEmpty()) {
                top_word_list.add(top_50_words.poll());
            }

            // Emit the top 50 words in descending order of their counts
            for (int i = top_word_list.size() - 1; i >= 0; i--) {
                WordCountDS wcds = top_word_list.get(i);
                context.write(new Text(wcds.get_word()), new IntWritable(wcds.get_count()));
            }
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "wordcount2");

        job.setMapperClass(Mapper_1.class);
        job.setReducerClass(Reducer_1.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        for (int i = 0; i < args.length; ++i) {
            if ("-skippatterns".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.skip.patterns", true);
                job.addCacheFile(new Path(args[++i]).toUri());
            } else if ("-casesensitive".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.case.sensitive", true);
            }
        }

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setJarByClass(Q1A.class);
        job.waitForCompletion(true);
    }
}
// cp /home/ricky/Desktop/sem6/NoSql/final_codes/q1a/q1a.jar
// hadoop jar q1a.jar /tar_testers /outputs/q1a -skippatterns /stopWords/stopwords.txt -casesensitive 