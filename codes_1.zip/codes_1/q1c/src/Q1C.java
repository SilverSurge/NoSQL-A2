import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.DataInput;
import java.io.DataOutput;
import java.util.Collections;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.StringUtils;

class CompositeValue implements WritableComparable<CompositeValue> {

    private int n;
    private ArrayList<Integer> counts;
    // Default constructor for (de)serialization
    public CompositeValue() {
        n = 0;
        counts = new ArrayList<Integer>();
    }

    public CompositeValue(int _n) {
        n = _n;
        counts = new ArrayList<Integer>(n);
        for(int i=0; i<n; i++)
            counts.add(0);
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeInt(n);
        for (int i = 0; i < n; i++) {
            out.writeInt(counts.get(i));
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        n = in.readInt();
        counts.clear(); // Clear existing counts
        for (int i = 0; i < n; i++) {
            counts.add(in.readInt());
        }
    }

    // helper functions

    public void reset()
    {
        for(int i=0; i<n; i++)
            counts.set(i, 0);
    }
    public void increment(int _idx)
    {
        if(_idx < n && _idx >= 0)
        {
            counts.set(_idx, counts.get(_idx)+1);
        }
    }

    public int get_n()
    {
        return n;
    }

    public int get_idx(int idx)
    {
        if(idx < n && idx >= 0)
            return counts.get(idx);
        return 0;
    }

    void add(CompositeValue cval)
    {
        if(cval.get_n() != n)
            return;
        for(int i=0; i < n; i++)
        {
            counts.set(i, counts.get(i) + cval.get_idx(i));
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + n;
        result = prime * result + ((counts == null) ? 0 : counts.hashCode());
        return result;
    }


    @Override
    public String toString() {
        String res = "";
        for(int i=0; i<n; i++)
            res += counts.get(i).toString() + " ";
        return res;
    }

    @Override
    public int compareTo(CompositeValue o) {
        // don't need to compare
        return 0;
    }
    
};

public class Q1C {


    public static class Mapper_1 extends Mapper<Object, Text, Text, CompositeValue> {
        // attributes for emitting
        Text word = new Text();
        CompositeValue word_value = new CompositeValue();

        // attributes related to the task
        private boolean case_sensitive = false;
        private ArrayList<String> word_50 = new ArrayList<String>();
        private int distance = 1;

        @Override
        public void setup(Context context) throws IOException, InterruptedException {

            // if we have to skip certain words we add the words using the parseSkipFile
            // helper function
            Configuration conf = context.getConfiguration();
            case_sensitive = conf.getBoolean("wordcount.case.sensitive", false);
            if (conf.getBoolean("wordcount.top50", false)) {
                URI[] patternsURIs = Job.getInstance(conf).getCacheFiles();
                for (URI patternsURI : patternsURIs) {
                    Path patternsPath = new Path(patternsURI.getPath());
                    String patternsFileName = patternsPath.getName().toString();
                    parseWordFile(patternsFileName);
                }
            }

            // sort the words lexicographically
            Collections.sort(word_50);
            this.distance = conf.getInt("wordcount.distance", 1);
            word_value = new CompositeValue(word_50.size());
        }

        private void parseWordFile(String fileName) {
            // read the file and add the words to the hashset
            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String pattern = null;
                while ((pattern = reader.readLine()) != null) {
                    word_50.add(pattern.split("\t")[0]);
                }
                reader.close();
            } catch (IOException ioe) {
                System.err.println(
                        "Caught exception while parsing the cached file '" + StringUtils.stringifyException(ioe));
            }
        }

        private int find_idx(String word) {
            int idx = 0;
            for (String w : word_50) {
                if(word.equals(w))
                    return idx;
                idx++;
            }
            return -1;
        }

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            // change to lower case if not case sensitive
            String line = (case_sensitive) ? value.toString() : value.toString().toLowerCase();

            // split the line in words
            String[] tokens = line.split("[^\\w']+");
            int n = tokens.length;
            int i = 0, j = 0;


            while (j < n) {
                while (j - i < this.distance && j < n)
                    j++;

                if (j>=n) {
                    break;
                }

                if (j - i == this.distance) {
                    if (this.word_50.contains(tokens[i]) && this.word_50.contains(tokens[j])) {
                        String w1 = tokens[i];
                        String w2 = tokens[j];
                        int idx_1 = find_idx(w1);
                        int idx_2 = find_idx(w2);

                        if(idx_1 == idx_2)
                        {
                            // emit [{w1, w2}, 1]
                            word.set(w1);
                            word_value.reset();
                            word_value.increment(idx_2);
                            context.write(word, word_value);
                        }
                        else 
                        {
                            // emit [w1, map1]
                            word.set(w1);
                            word_value.reset();
                            word_value.increment(idx_2);
                            context.write(word, word_value);

                            // emit [w2, map2]
                            word.set(w2);
                            word_value.reset();
                            word_value.increment(idx_1);
                            context.write(word, word_value);
                        }
                        
                    }
                    
                }
                
                i++;
            }

            while(i < n)
            {
                if(this.word_50.contains(tokens[i]) )
                {
                    word.set(tokens[i]);
                    word_value.reset();
                    context.write(word, word_value);
                }
                i++;
            }

        }

    }

    public static class Reducer_1 extends Reducer<Text, CompositeValue, Text, CompositeValue> {

        @Override
        public void reduce(Text key, Iterable<CompositeValue> values, Context context)
                throws IOException, InterruptedException {
                
                // adding all the values
                Iterator<CompositeValue> iterator = values.iterator();
                CompositeValue first = iterator.next();
                CompositeValue result = new CompositeValue(first.get_n());
                result.reset();
                result.add(first);
                
                for(CompositeValue value: values)
                {
                    result.add(value);
                    // context.write(key, value);
                }
                context.write(key, result);
        }

    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "q1c");

        job.setMapperClass(Mapper_1.class);
        job.setReducerClass(Reducer_1.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(CompositeValue.class);

        for (int i = 0; i < args.length; ++i) {
            if ("-wordlist".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.top50", true);
                job.addCacheFile(new Path(args[++i]).toUri());
            } else if ("-casesensitive".equals(args[i])) {
                job.getConfiguration().setBoolean("wordcount.case.sensitive", true);
            } else if ("-distance".equals(args[i])) {
                job.getConfiguration().setInt("wordcount.distance", Integer.parseInt(args[++i]));
            }
        }

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setJarByClass(Q1C.class);
        job.waitForCompletion(true);
    }
}

// /home/ricky/Desktop/sem6/NoSql/final_codes/q1c/q1c.jar
// hadoop jar q1c.jar /tar_testers /outputs/q1c -wordlist /outputs/q1a/part-r-00000 -casesensitive -distance 2

